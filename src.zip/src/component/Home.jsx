import React from 'react';

const Home = () => <div className="row">
    <div className="col-md-4 col-xs-12"></div>
    <div className="col-md-4 col-xs-12 text-center">
        <img src="/image/me.jpg" alt="saharsh sinha" className="img img-thumbnail"/>
        <h3>Movie Browser App</h3>
        <p>Powered by react 16.14.0</p>
    </div>
    <div className="col-md-4 col-xs-12"></div>
</div>;


export default Home;